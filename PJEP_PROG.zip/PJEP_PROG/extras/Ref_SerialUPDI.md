# SerialUPDI
[Relocated to keep all information in one place](https://github.com/SpenceKonde/AVR-Guidance/blob/master/UPDI/jtag2updi.md)
